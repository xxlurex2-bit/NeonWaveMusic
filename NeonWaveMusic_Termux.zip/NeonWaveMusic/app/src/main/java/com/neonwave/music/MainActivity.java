package com.neonwave.music;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int PURPLE = Color.rgb(181,156,255);
    private final int BG = Color.rgb(16,13,28);
    private final int PANEL = Color.rgb(34,27,54);
    private final ArrayList<Track> tracks = new ArrayList<>();
    private MediaPlayer player;
    private int current = -1;
    private TextView nowTitle, nowArtist, status, playButton;
    private LinearLayout songList;
    private SeekBar seek;
    private boolean userSeeking = false;

    static class Track {
        long id; String title, artist; Uri uri;
        Track(long i, String t, String a, Uri u) { id=i; title=t; artist=a; uri=u; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        if (hasAudioPermission()) loadTracks(); else requestPermissions(new String[]{audioPermission()}, 7);
    }
    private String audioPermission() { return Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE; }
    private boolean hasAudioPermission() { return Build.VERSION.SDK_INT < 23 || checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED; }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(24),dp(20),dp(10)); root.setBackgroundColor(BG);
        TextView brand = text("NEONWAVE  ✦", 14, PURPLE, true); root.addView(brand);
        TextView heading = text("Your sound.\nYour universe.", 30, Color.WHITE, true); LinearLayout.LayoutParams hp = params(-1,-2); hp.topMargin=dp(12); root.addView(heading,hp);
        status = text("YOUR LIBRARY", 12, 0xffA9A2BC, true); LinearLayout.LayoutParams sp=params(-1,-2); sp.topMargin=dp(20); root.addView(status,sp);
        ScrollView scroll = new ScrollView(this); songList = new LinearLayout(this); songList.setOrientation(LinearLayout.VERTICAL); scroll.addView(songList); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,0,1); lp.topMargin=dp(10); root.addView(scroll,lp);
        LinearLayout playerPanel = new LinearLayout(this); playerPanel.setOrientation(LinearLayout.VERTICAL); playerPanel.setPadding(dp(16),dp(16),dp(16),dp(14)); playerPanel.setBackground(round(PANEL,22));
        nowTitle=text("Choose a song",18,Color.WHITE,true); nowArtist=text("Your local music will appear above",13,0xffB6AFC9,false); playerPanel.addView(nowTitle); LinearLayout.LayoutParams ap=params(-1,-2); ap.topMargin=dp(5); playerPanel.addView(nowArtist,ap);
        seek=new SeekBar(this); seek.setProgressTintList(android.content.res.ColorStateList.valueOf(PURPLE)); seek.setThumbTintList(android.content.res.ColorStateList.valueOf(PURPLE)); playerPanel.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar b,int p,boolean u){userSeeking=u;} public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){if(player!=null&&player.isPlaying())player.seekTo(b.getProgress());}});
        LinearLayout controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setOrientation(LinearLayout.HORIZONTAL);
        Button prev=button("|◀"); prev.setOnClickListener(v->playIndex(current-1)); controls.addView(prev);
        playButton=text("▶",22,Color.WHITE,true); playButton.setGravity(Gravity.CENTER); playButton.setBackground(round(PURPLE,40)); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(60),dp(52)); pp.setMargins(dp(18),0,dp(18),0); controls.addView(playButton,pp); playButton.setOnClickListener(v->togglePlay());
        Button next=button("▶|"); next.setOnClickListener(v->playIndex(current+1)); controls.addView(next); playerPanel.addView(controls); LinearLayout.LayoutParams bp=params(-1,-2); bp.topMargin=dp(8); root.addView(playerPanel,bp);
        setContentView(root);
    }
    private void loadTracks() {
        tracks.clear(); songList.removeAllViews();
        Uri collection=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST};
        String selection=MediaStore.Audio.Media.IS_MUSIC+" != 0";
        try(Cursor c=getContentResolver().query(collection,projection,selection,null,MediaStore.Audio.Media.TITLE+" COLLATE NOCASE ASC")) {
            if(c!=null) while(c.moveToNext()) {
                long id=c.getLong(0); String title=c.getString(1); String artist=c.getString(2);
                if(title==null||title.trim().isEmpty())title="Unknown track"; if(artist==null||artist.trim().isEmpty()||artist.equals("<unknown>"))artist="Unknown artist";
                tracks.add(new Track(id,title,artist,ContentUris.withAppendedId(collection,id)));
            }
        } catch(Exception e) { Toast.makeText(this,"Couldn't read music library",Toast.LENGTH_LONG).show(); }
        status.setText("YOUR LIBRARY  ·  "+tracks.size()+" TRACKS");
        if(tracks.isEmpty()){ TextView empty=text("No songs found. Add audio files to your phone and try again.",15,0xffB6AFC9,false); empty.setPadding(0,dp(18),0,dp(18)); songList.addView(empty); return; }
        for(int i=0;i<tracks.size();i++) addTrackRow(i,tracks.get(i));
    }
    private void addTrackRow(int index, Track t) {
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(12),dp(12),dp(12),dp(12)); row.setBackground(round(PANEL,16)); LinearLayout.LayoutParams rp=params(-1,-2); rp.bottomMargin=dp(8); songList.addView(row,rp);
        TextView disc=text("♫",22,PURPLE,true); disc.setGravity(Gravity.CENTER); row.addView(disc,new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout names=new LinearLayout(this); names.setOrientation(LinearLayout.VERTICAL); names.setPadding(dp(12),0,dp(4),0); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,-2,1); row.addView(names,np);
        TextView title=text(t.title,15,Color.WHITE,true); TextView artist=text(t.artist,12,0xffB6AFC9,false); names.addView(title); names.addView(artist);
        TextView more=text("•••",18,Color.WHITE,true); row.addView(more); row.setOnClickListener(v->playIndex(index));
    }
    private void playIndex(int index) {
        if(tracks.isEmpty())return; if(index<0)index=tracks.size()-1; if(index>=tracks.size())index=0; current=index; Track t=tracks.get(current);
        try { if(player!=null){player.release();player=null;} player=new MediaPlayer(); player.setDataSource(this,t.uri); player.setOnPreparedListener(mp->{mp.start(); playButton.setText("Ⅱ"); seek.setMax(Math.max(1,mp.getDuration())); nowTitle.setText(t.title); nowArtist.setText(t.artist);}); player.setOnCompletionListener(mp->playIndex(current+1)); player.setOnErrorListener((mp,what,extra)->{Toast.makeText(this,"This file can't be played",Toast.LENGTH_SHORT).show();return true;}); nowTitle.setText(t.title); nowArtist.setText("Loading track…"); player.prepareAsync(); }
        catch(IOException|IllegalStateException e){Toast.makeText(this,"Unable to play this track",Toast.LENGTH_SHORT).show();}
    }
    private void togglePlay(){ if(player==null){if(!tracks.isEmpty())playIndex(current<0?0:current);return;} if(player.isPlaying()){player.pause();playButton.setText("▶");}else{player.start();playButton.setText("Ⅱ");} }
    private Button button(String label){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackground(round(PANEL,16));return b;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout.LayoutParams params(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private android.graphics.drawable.GradientDrawable round(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results);if(requestCode==7&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)loadTracks();else Toast.makeText(this,"Allow audio access to show your songs",Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){if(player!=null){player.release();player=null;}super.onDestroy();}
}
