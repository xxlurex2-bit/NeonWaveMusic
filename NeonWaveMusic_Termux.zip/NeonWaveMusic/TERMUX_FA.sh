#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update
pkg install openjdk-17 unzip git -y
printf '\nJDK نصب شد. توجه: این مرحله Android SDK و ابزارهای Build را نصب نمی‌کند.\n'
printf 'برای ساخت APK باید Android SDK و Gradle سازگار نیز نصب و پیکربندی شوند.\n'
